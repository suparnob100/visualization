Path = fileparts(mfilename('fullpath'));
addpath(Path)
addpath(Path+"/sub_functions/")
addpath(Path+"/utils/")
addpath(Path+"/utils/export_fig")
addpath(Path+"/utils/matplotlib")